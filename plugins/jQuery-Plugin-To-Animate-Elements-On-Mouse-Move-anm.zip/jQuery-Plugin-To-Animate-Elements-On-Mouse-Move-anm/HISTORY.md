# 1.1.0 / 2015.01.16

  * Add npm support #5
  * Add component support #4
  * Add scaling, opacity and rotation #1 #2 #3
  * Fix IE detection
  * Fix add event listeners

# 1.0.1 / 2014.10.18

  * Add touch support
